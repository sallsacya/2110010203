/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package salsabila_project;
import dataset,*;
import java.util.ArrayList;
/**
 *
 * @author LENOVO
 */
public class Salsabila_project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // penyediaan barang 
          /**PersediaanBarang barang_masuk = new barang_masuk();
          PersediaanBarang barang_keluar = new barang_keluar();
          PersediaanBarang barang = new barang();
          PersediaanBarang jenis_barang = new jenis_barang();
          PersediaanBarang satuan = new satuan();
          PersediaanBarang user = new user();
         
         //user
         //SET
          user.setid_user (01);
          user.setusername (sallsacya);
          user.setnama_user (salsabila);
          user.setPassword (cantik);
          user.setEmail (salsabila@gmail.com);
          user.setTelepon (083821204079);
        //GET
         System.out.println("id_user    : " + User.getiduser()));
         System.out.println("username    : " + User.getusername()));
         System.out.println("nama_user    : " + User.getnamauser()));
         System.out.println("password    : " + User.getpassword()));
         System.out.println("email    : " + User.getemail()));
         System.out.println("telepon   : " + User.gettelepon()));
         
         //barang
         //SET
         barang.setid_barang(mesin);
         * 
       
      
        
        */
        
        
    }
    
}
