/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataset;
import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author LENOVO
 */

public class ds_barang {
    private String id_barang;
    private String nama_barang;
    private int id_jenis;
    private int id_satuan;
    private int stok;
    private int created_user;
    private Date created_date;
    private int updated_user;
    private Date updated_date;
    
    public ds_barang(String id_barang, String nama_barang, int id_jenis, int id_satuan, int stok, int created_user, Date created_date, int updated_user, Date updated_date) {
        this.id_barang = id_barang;
        this.nama_barang = nama_barang;
        this.id_jenis = id_jenis;
        this.id_satuan = id_satuan;
        this.stok = stok;
        this.created_user = created_user;
        this.created_date = created_date;
        this.updated_user = updated_user;
        this.updated_date = updated_date;
    }
    
    public String getIdBarang() {
        return id_barang;
    }

    public void setIdBarang(String id_barang) {
        this.id_barang = id_barang;
    }
    
    public String getNamaBarang() {
        return nama_barang;
    }

    public void setNamaBarang(String nama_barang) {
        this.nama_barang = nama_barang;
    }
    
    public int getIdJenis() {
        return id_jenis;
    }

    public void setIdJenis(int id_jenis) {
        this.id_jenis = id_jenis;
    }
    
    public int getIdSatuan() {
        return id_satuan;
    }

    public void setIdSatuan(int id_satuan) {
        this.id_satuan = id_satuan;
    }
    
    public int getStok() {
        return stok;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }
    
    public int getCreatedUser() {
        return created_user;
    }

    public void setCreatedUser(int created_user) {
        this.created_user = created_user;
    }
    
     public Date getCreatedDate() {
        return created_date;
    }

    public void setCreatedDate(Date created_date) {
        this.created_date = created_date;
    }
    
     public int getUpdatedUser() {
        return updated_user;
    }

    public void setUpdatedUser(int updated_user) {
        this.updated_user = updated_user;
    }
    
     public Date getUpdatedDate() {
        return updated_date;
    }

    public void setUpdatedDate(Date updated_date) {
        this.updated_date = updated_date;
    }
}

