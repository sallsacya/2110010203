/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataset;

/**
 *
 * @author ACER
 */
import java.util.ArrayList;
import java.util.Date;

public class ds_barang_keluar {
    private String id_barang_keluar;
    private Date tanggal_keluar;
    private int id_barang;
    private int jumlah_keluar;
    private int created_user;
    private Date created_date;
    
    public ds_barang_keluar(String id_barang_keluar, Date tanggal_keluar, int id_barang, int jumlah_keluar, int created_user, Date created_date) {
        this.id_barang_keluar = id_barang_keluar;
        this.tanggal_keluar = tanggal_keluar;
        this.id_barang = id_barang;
        this.jumlah_keluar = jumlah_keluar;
        this.created_user = created_user;
        this.created_date = created_date;
    }
    
    public String getIdBarangKeluar() {
        return id_barang_keluar;
    }

    public void setIdBarangKeluar(String id_barang_keluar) {
        this.id_barang_keluar = id_barang_keluar;
    }
    
    public Date getTanggalKeluar() {
        return tanggal_keluar;
    }

    public void setTanggalKeluar(Date tanggal_keluar) {
        this.tanggal_keluar = tanggal_keluar;
    }
    
    public int getIdBarang() {
        return id_barang;
    }

    public void setIdBarang(int id_barang) {
        this.id_barang = id_barang;
    }
    
    public int getJumlahKeluar() {
        return jumlah_keluar;
    }

    public void setJumlahKeluar(int jumlah_keluar) {
        this.jumlah_keluar = jumlah_keluar;
    }
    
    public int getCreatedUser() {
        return created_user;
    }

    public void setCreatedUser(int created_user) {
        this.created_user = created_user;
    }
    
     public Date getCreatedDate() {
        return created_date;
    }

    public void setCreatedDate(Date created_date) {
        this.created_date = created_date;
    }
}