/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataset;

/**
 *
 * @author LENOVO
 */
import java.util.ArrayList;
import java.util.Date;

public class ds_barang_masuk {
    private String id_barang_masuk;
    private Date tanggal_masuk;
    private int id_barang;
    private int jumlah_masuk;
   
    
    public ds_barang_masuk(String id_barang_masuk, Date tanggal_masuk, int id_barang, int jumlah_masuk) {
        this.id_barang_masuk = id_barang_masuk;
        this.tanggal_masuk = tanggal_masuk;
        this.id_barang = id_barang;
        this.jumlah_masuk = jumlah_masuk;
    }
    
    public String getIdBarangMaasuk() {
        return id_barang_masuk;
    }

    public void setIdBarangMasuk(String id_barang_masuk) {
        this.id_barang_masuk = id_barang_masuk;
    }
    
    public Date getTanggalMasuk() {
        return tanggal_masuk;
    }

    public void setTanggalMasuk(Date tanggal_masuk) {
        this.tanggal_masuk = tanggal_masuk;
    }
    
    public int getIdBarang() {
        return id_barang;
    }

    public void setIdBarang(int id_barang) {
        this.id_barang = id_barang;
    }
    
    public int getJumlahMasuk() {
        return jumlah_masuk;
    }

    public void setJumlahMasuk(int jumlah_masuk) {
        this.jumlah_masuk = jumlah_masuk;
    }
   
}

